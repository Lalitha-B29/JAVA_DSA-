import java.util.Scanner;
import java.util.Arrays;
public class Sortedcol {
    public static void sorting(int r,int c,int mat[][])
    {
        for(int j=0;j<r;j++)
        {

        
        int temp[]=new int[c];
     for(int i=0;i<c;i++)
     {
        temp[i]=mat[i][j];
             
     }Arrays.sort(temp); 
     for(int i=0;i<c;i++)
     {
        mat[i][j]=temp[i];
     }}
     System.out.println(Arrays.deepToString(mat));

    }
     public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    int r=sc.nextInt();
    int c=sc.nextInt();
    int mat[][]=new int[r][c];
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            mat[i][j]=sc.nextInt();
        }
    }
    sorting(r, c, mat);
}
}
