import java.util.*;
public class Arrays {
    public static void main(String[] args)
    {
       /*  String str="java";
        boolean result;
        result=str instanceof String;
        System.out.println(result);*/ /*int[] num=new int[6];
        boolean result;
        result=num instanceof int[];
        System.out.println(result);*/
        
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        //System.out.print(Arrays.toString(arr));
        //int sum=0;
        /*for(int i=0;i<arr.length;i++)
        {
            sum+=arr[i];
        }*/
        /*for(int num:arr)
        {
            System.out.print(num+" ");
        }*/
        
        
       
    }
}
