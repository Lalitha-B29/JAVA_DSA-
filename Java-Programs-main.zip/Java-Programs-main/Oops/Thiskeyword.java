public class Thiskeyword {
    int a=10,b=20,c=30;
    
}
